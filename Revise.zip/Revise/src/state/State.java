package state;

public interface State {
    public void set(MusicPlayer musicPlayer);
    public void show();
}

class MusicPlayer{
    private State  state;
    public void setState(State state){
        this.state = state;
    }

    public State getState(){
      return state;
    }
}

class StopState implements State{

    @Override
    public void set(MusicPlayer musicPlayer) {
       musicPlayer.setState(this);
    }

    @Override
    public void show() {
        System.out.printf("音乐停止！\n");
    }
}

class PlayingState implements State{

    @Override
    public void set(MusicPlayer musicPlayer) {
        musicPlayer.setState(this);
    }

    @Override
    public void show() {
        System.out.printf("开始播放！\n");
    }
}

class PausedState implements State{

    @Override
    public void set(MusicPlayer musicPlayer) {
        musicPlayer.setState(this);
    }

    @Override
    public void show() {
        System.out.printf("暂停播放！\n");
    }
}

class Demo{
    public static void main(String[] args) {
     MusicPlayer musicPlayer = new MusicPlayer();
     StopState stopState = new StopState();
     stopState.set(musicPlayer);
     musicPlayer.getState().show();
    }
}



