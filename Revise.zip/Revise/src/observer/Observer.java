package observer;

import java.util.ArrayList;
import java.util.List;

public interface Observer {
    public void display();
}

class PhoneDisplayer implements Observer{

    @Override
    public void display() {
        System.out.printf("在手机屏幕上显示");
    }
}

class WebsiteDisplayer implements Observer{

    @Override
    public void display() {
        System.out.printf("在网站上显示");
    }
}

class ScreenDisplayer implements Observer{

    @Override
    public void display() {
        System.out.printf("在大屏幕上显示");
    }
}

interface Subject{
    public void addObservers(Observer observer);
    public void removeObservers(Observer observer);
    public void notifyObservers();
}

class Weather implements Subject{
    public List<Observer> observers = new ArrayList<Observer>();

    @Override
    public void addObservers(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObservers(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for(Observer observer : observers){
            observer.display();
        }
    }
}

class Demo{
    public static void main(String[] args) {
        PhoneDisplayer phoneDisplayer = new PhoneDisplayer();
        ScreenDisplayer screenDisplayer = new ScreenDisplayer();
        WebsiteDisplayer websiteDisplayer = new WebsiteDisplayer();

        // 创建WeatherData实例
        Weather weather = new Weather();

        // 注册观察者
        weather.addObservers(phoneDisplayer);
        weather.addObservers(screenDisplayer);
        weather.addObservers(websiteDisplayer);

        weather.notifyObservers();
    }
}


