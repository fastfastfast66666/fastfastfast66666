package constructor;


public class Computer {
    private String CPU = null;
    private String RAM = null;
    private String Storage= null;
    private String GPU= null;
    private String PowerSupply= null;
    private String OperatingSystem= null;


    public String getCPU() {
        return CPU;
    }

    public void setCPU(String CPU) {
        this.CPU = CPU;
    }

    public String getRAM() {
        return RAM;
    }

    public void setRAM(String RAM) {
        this.RAM = RAM;
    }

    public String getStorage() {
        return Storage;
    }

    public void setStorage(String storage) {
        Storage = storage;
    }

    public String getGPU() {
        return GPU;
    }

    public void setGPU(String GPU) {
        this.GPU = GPU;
    }

    public String getPowerSupply() {
        return PowerSupply;
    }

    public void setPowerSupply(String powerSupply) {
        PowerSupply = powerSupply;
    }

    public String getOperatingSystem() {
        return OperatingSystem;
    }

    public void setOperatingSystem(String operatingSystem) {
        OperatingSystem = operatingSystem;
    }

    public void show(){
        System.out.println("您的电脑配置: \n"
                +"CPU: " + CPU + "\n"
                +"RAM: " + RAM + "\n"
                +"Storage: " + Storage + "\n"
                +"GPU: " + GPU + "\n"
                +"PowerSupply: " + PowerSupply + "\n"
                +"OperatingSystem: " +OperatingSystem + "\n");
    }
}

interface Builder{
    public void setcpu(String component);
    public void setram(String component);
    public void setstorage(String component);
    public void setgpu(String component);
    public void setpowersupply(String component);
    public void setoperatingsystem(String component);

    public Computer build();

}

class NoGPUBuilder implements Builder{
    Computer computer ;
    NoGPUBuilder(Computer computer){
        this.computer = computer;
    }
    @Override
    public void setcpu(String component) {
           computer.setCPU(component);
    }

    @Override
    public void setram(String component) {
        computer.setRAM(component);
    }

    @Override
    public void setstorage(String component) {
        computer.setStorage(component);
    }

    @Override
    public void setgpu(String component) {
    }

    @Override
    public void setpowersupply(String component) {
        computer.setPowerSupply(component);
    }

    @Override
    public void setoperatingsystem(String component) {
        computer.setOperatingSystem(component);
    }

    @Override
    public Computer build() {
        return computer;
    }
}

class GPUBuilder implements Builder{
    Computer computer;

    GPUBuilder(Computer computer){
        this.computer = computer;
    }
    @Override
    public void setcpu(String component) {
    }

    @Override
    public void setram(String component) {
    }

    @Override
    public void setstorage(String component) {
    }

    @Override
    public void setgpu(String component) {
        computer.setPowerSupply(component);
    }

    @Override
    public void setpowersupply(String component) {
    }

    @Override
    public void setoperatingsystem(String component) {
    }

    @Override
    public Computer build() {
        return computer;
    }
}

class Director{
    Computer computer;
    public Computer constructALLComputer(){
        Builder noGPUBuilder = new NoGPUBuilder(computer);
        Builder gpuBuilder = new GPUBuilder(computer);
        noGPUBuilder.setcpu("i5-12600k");
        noGPUBuilder.setram("闪光6400HZ");
        noGPUBuilder.setstorage("三星980pro 1TB");
        noGPUBuilder.setpowersupply("海盗船");
        noGPUBuilder.setoperatingsystem("win10");
        computer = noGPUBuilder.build();
        gpuBuilder.setgpu("4090");
        computer = gpuBuilder.build();

        return computer;
    }
}

class TEST{
    public static void main(String[] args) {
        Director director = new Director();
        Computer computer = director.constructALLComputer();
        computer.show();
    }
}


