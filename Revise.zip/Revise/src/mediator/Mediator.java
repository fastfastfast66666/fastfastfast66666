package mediator;

import java.util.ArrayList;
import java.util.List;

public interface Mediator {
    public void sendMessage(String message,User user);
    public void addUser(User user);

}

class ChatMediator implements Mediator{
    List<User> users = new ArrayList<User>();

    @Override
    public void sendMessage(String message, User user) {
          for(User user1 : users){
              if(user1 != user){
                  user1.receive(message);
              }
          }

    }

    @Override
    public void addUser(User user) {
        users.add(user);
    }
}

abstract class User{
    Mediator mediator;
    String name;

    public abstract void send(String message);

    public abstract void receive(String message);

}

class ChatUser extends User{


    public ChatUser(Mediator mediator,String name) {
        this.mediator = mediator;
        this.name = name;
    }

    @Override
    public void send(String message) {
         mediator.sendMessage(message,this);
    }

    @Override
    public void receive(String message) {
        System.out.printf("User: "+name+" Receive message : "+message);
    }
}


class Main{
    public static void main(String[] args) {
        ChatMediator chatMediator  = new ChatMediator();
          ChatUser user1 = new ChatUser(chatMediator,"Bob");
        ChatUser user2 = new ChatUser(chatMediator,"Jucy");
        ChatUser user3 = new ChatUser(chatMediator,"Karia");
        ChatUser user4 = new ChatUser(chatMediator,"FUck");

        chatMediator.addUser(user1);
        chatMediator.addUser(user2);
        chatMediator.addUser(user3);
        chatMediator.addUser(user4);

        user1.send("fuck all of you \n");
    }
}
