package state_plus_observer;

import java.util.ArrayList;
import java.util.List;

public interface LightState {

    public void doAction(Trafficlight trafficlight);
    public void operation();
    public String getLight();

}

class RedLightState implements LightState{
    String light = "Red";

    @Override
    public void doAction(Trafficlight trafficlight) {
        trafficlight.setState(this);
    }

    @Override
    public void operation() {
        System.out.printf("Red\n");
    }

    public String getLight(){
        return light;
    };
}

class Trafficlight{
    List<Observer> observers = new ArrayList<Observer>();
    LightState lightState;

    public void add(Observer observer){
        observers.add(observer);
    }

    public void remove(Observer observer){
        observers.remove(observer);
    }

    public void notifyAllObservers(){
        lightState.operation();
        for(Observer observer : observers){
            observer.run(this.lightState);
        }
    }

    public void setState(LightState lightState){
       this.lightState = lightState;
        lightState.operation();
        System.out.printf("到这里正确");
        notifyAllObservers();
    }

    public LightState getState(){
        return lightState;
    }
}

interface Observer{
    public void run(LightState lightState);
}

class Car implements Observer{

    @Override
    public void run(LightState lightState) {
        if(lightState.getLight() == "Red") {
            System.out.printf("Car Stop");
        }
        else if(lightState.getLight() == "Green"){
            System.out.printf("Car Run");
        }else if(lightState.getLight() == "Yellow"){
            System.out.printf("Car Pause");
        }else {
            System.out.printf("Nothing");
        }
    }
}

class Demo{
    public static void main(String[] args) {
        Car car = new Car();
        Trafficlight trafficlight = new Trafficlight();
        RedLightState redLightState = new RedLightState();
        trafficlight.add(car);
        trafficlight.setState(redLightState);
    }
}


