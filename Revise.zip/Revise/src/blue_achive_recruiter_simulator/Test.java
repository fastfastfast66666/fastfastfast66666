package blue_achive_recruiter_simulator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Test {
    public static final String ANSI_RESET = "\033[0m";
    public static final String BRIGHT_CYAN = "\033[0;96m";
    public static final String ANSI_PURPLE = "\033[0;35m";
    public static final String ANSI_LIGHT_PURPLE = "\033[0;95m";
    public static final String BRIGHT_YELLOW = "\033[0;93m";
    public static final String BRIGHT_BLUE = "\033[0;94m";
    public static final String BRIGHT = "\033[38;5;123m";
    public static void main(String[] args) {
        System.out.printf("请输入你的清辉石数量：\n");
        Scanner crystal_scanner = new Scanner(System.in);
        int Crystals_remain = (int) crystal_scanner.nextDouble();
        System.out.printf("请选择你的卡池概率： 1.普通UP池 2.FES池\n");
        Scanner whichpool_scanner = new Scanner(System.in);
        Caculator calculator ;

        if(whichpool_scanner.nextLine().equals("1")){
            calculator = new ProbabilityCalculator();
        }else {
            calculator = new FES_ProbabilityCalculator();
        }


        int Crystals_remain_copy = Crystals_remain;
        int Draw_Count_UP_3 = 0;
        int Draw_Count_NoUp_3 = 0;
        int Draw_Count_2 = 0;
        int Draw_Count_1 = 0;
        int Draw_Sequence_Caculator = 0;
        Boolean Has_Get_UP = false;
        List<StudentCard> studentCards_3_stack = new ArrayList<StudentCard>();

        while (true) {
            System.out.printf("------------------------正在载入水星野UP卡池啊嗯------------------------------------------------------------\n");
            System.out.printf(BRIGHT+"请选择你的抽卡方式：\n"+"1.单独抽取 \n"+"2.十连抽取 \n"+"3.查看抽取结果\n"+"4.查看已经抽取的彩卡\n"+ANSI_RESET);
            Scanner scanner = new Scanner(System.in);
            List<StudentCard> cardPool = new ArrayList<>();

            // 读取文件并生成学生卡片
            try (BufferedReader reader = new BufferedReader(new FileReader("F:\\JAVA\\20240423\\Revise\\src\\blue_achieve_recruiter_simulator\\formatted_students.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 3) {
                        String name = parts[0];
                        String starLevel = parts[1];
                        boolean isUp = Boolean.parseBoolean(parts[2]);
                        cardPool.add(new StudentCard(starLevel, isUp, name));
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            // 创建概率计算器

            switch (scanner.nextLine()) {
                case "1":
                    if(Crystals_remain>=120) {
                        System.out.printf("------------------------加载单抽-------------------------------------------------------------------------\n");
                        SingleStrategy singleDrawStrategy = new SingleStrategy(calculator, cardPool);
                        singleDrawStrategy.draw().show();

                        //计算抽取结果
                        if(singleDrawStrategy.draw().getStarLevel().equals("3")){
                            if(singleDrawStrategy.draw().getName().equals("星野(泳装)")){
                                Draw_Count_UP_3++;
                                Has_Get_UP = true;
                            }
                            else {
                                Draw_Count_NoUp_3++;
                            }
                            studentCards_3_stack.add(singleDrawStrategy.draw());
                        } else if (singleDrawStrategy.draw().getStarLevel().equals("2")) {
                            Draw_Count_2++;
                        }else {
                            Draw_Count_1++;
                        }
                        Draw_Sequence_Caculator++;
                        Crystals_remain-=120;
                        System.out.printf("\n目前抽取次数 : "+ BRIGHT_CYAN + Draw_Sequence_Caculator+ ANSI_RESET + " 次\n"+"还剩 "+ BRIGHT_CYAN + Crystals_remain + ANSI_RESET + " 石头 \n");
                    }else {
                    System.out.printf("石头不够了！byd是不是没忍住抽xp了？\n");
                }
                break;
                case "2":
                    if(Crystals_remain>=1200) {
                        System.out.printf("------------------------加载十连抽------------------------------------------------------------------------\n");
                        TenDrawStrategy tenDrawStrategy = new TenDrawStrategy(calculator, cardPool);
                        int index = 1;

                        for (StudentCard studentCard : tenDrawStrategy.ten_draw_result()) {

                            studentCard.ten_show();
                            if (index == 5) {
                                System.out.printf("\n");
                            }
                            index++;
                            //计算抽取结果
                            if(studentCard.getStarLevel().equals("3")){
                                if(studentCard.getName().equals("星野(泳装)")){
                                    Draw_Count_UP_3++;
                                    Has_Get_UP = true;
                                }
                                else {
                                    Draw_Count_NoUp_3++;
                                }
                                studentCards_3_stack.add(studentCard);
                            } else if (studentCard.getStarLevel().equals("2")) {
                                Draw_Count_2++;
                            }else {
                                Draw_Count_1++;
                            }

                        }
                        Draw_Sequence_Caculator += 10;
                        Crystals_remain-=1200;
                        System.out.printf("\n目前抽取次数 : "+ BRIGHT_CYAN + Draw_Sequence_Caculator+ ANSI_RESET + " 次\n"+"还剩 "+ BRIGHT_CYAN + Crystals_remain + ANSI_RESET + " 石头 \n");

                    }else {
                        System.out.printf("石头不够了！byd是不是没忍住抽xp了？\n");
                    }
                break;
                case "3":
                    if(Crystals_remain_copy - Crystals_remain == 24000 && Has_Get_UP == false){
                        System.out.printf("恭喜吃井啊嗯!!\n");
                    }
                    System.out.printf("------------------------显示目前抽取结果-------------------------------------------------------------------\n");
                    System.out.println(ANSI_PURPLE+"获得的★★★数量: "+(Draw_Count_NoUp_3+Draw_Count_UP_3)+ANSI_LIGHT_PURPLE+" 其中UP卡数量: "+Draw_Count_UP_3+ANSI_RESET);
                    System.out.println(BRIGHT_YELLOW+"获得的★★数量: "+Draw_Count_2+ANSI_RESET);
                    System.out.println(BRIGHT_BLUE+"获得的★数量: "+Draw_Count_1+ANSI_RESET);
                    System.out.printf("\n目前抽取次数 : "+ BRIGHT_CYAN + Draw_Sequence_Caculator+ ANSI_RESET + " 次\n"+"还剩 "+ BRIGHT_CYAN + Crystals_remain + ANSI_RESET + " 石头 \n");
                    break;
                case "4":
                    System.out.printf("------------------------显示目前抽取结果-------------------------------------------------------------------\n");
                    int five_mutiply = 1;
                    if(studentCards_3_stack == null){
                        System.out.println("没有三星！！！");
                        break;
                    }
                    for (StudentCard studentCard : studentCards_3_stack) {
                        System.out.print(ANSI_LIGHT_PURPLE +"| " + studentCard.getName() + " " + studentCard.getStars() + " " + "| "+ ANSI_RESET);
                        if(five_mutiply % 5 == 0){
                            System.out.printf("\n");
                        }
                        five_mutiply++;
                    }
                    System.out.printf("\n");
                    break;
            }
            if(Crystals_remain_copy - Crystals_remain == 24000 && Has_Get_UP == false){
                System.out.printf("\n");
            }

        }
    }
}

