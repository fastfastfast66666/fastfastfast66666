package blue_achive_recruiter_simulator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class StudentFormatter {
    public static void main(String[] args) {
        String inputFile = "F:\\JAVA\\20240423\\Revise\\src\\blue_achieve_recruiter_simulator\\cardpool.txt";
        String outputFile = "F:\\JAVA\\20240423\\Revise\\src\\blue_achieve_recruiter_simulator\\formatted_students.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            String line;
            while ((line = reader.readLine()) != null) {
                // 默认星级为2，是否为UP卡为false
                String formattedLine = String.format("%s,2,false", line);
                writer.write(formattedLine);
                writer.newLine();
            }

            System.out.println("文件格式化完成。");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
