package blue_achive_recruiter_simulator;

public class StudentCardFactory {
    public static StudentCard createCard(String starLevel, boolean isUp, String name) {
        return new StudentCard(starLevel, isUp, name);
    }
}

class StudentCard{
    String starLevel;
    Boolean isUp;
    String name;
    public static final String ANSI_PURPLE = "\033[0;35m";
    public static final String ANSI_LIGHT_PURPLE = "\033[0;95m";
    public static final String BRIGHT_YELLOW = "\033[0;93m";
    public static final String ANSI_RESET = "\033[0m";
    public static final String BRIGHT_BLUE = "\033[0;94m";

    StudentCard(String starLevel,Boolean isUp,String name){
           this.starLevel = starLevel;
           this.name = name;
           this.isUp = isUp;
    }

    public String getStarLevel() {
        return starLevel;
    }

    public void setStarLevel(String starLevel) {
        this.starLevel = starLevel;
    }

    public Boolean getUp() {
        return isUp;
    }

    public void setUp(Boolean up) {
        isUp = up;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStars(){
        if(starLevel.equals("3")){
            return "★★★";
        }else if(starLevel.equals("2")){
            return "★★";
        }else if(starLevel.equals("1")){
            return "★";
        }else{
            return "出错";
        }
    }

    public void show(){
        if(this.getStarLevel().equals("3")) {
            if(this.getName().equals("星野(泳装)")) {
                System.out.print(ANSI_LIGHT_PURPLE +"| " + this.getName() + " " + this.getStars() + " " + "| \n"+ ANSI_RESET);
            }
            else{System.out.print(ANSI_PURPLE +"| " + this.getName() + " " + this.getStars() + " " + "| \n"+ ANSI_RESET);}
        }else if (this.getStarLevel().equals("2")){
            System.out.print(BRIGHT_YELLOW+"| " + this.getName() + " " + this.getStars() + " " + "| \n"+ ANSI_RESET);
        }else{
            System.out.print(BRIGHT_BLUE+"| " + this.getName() + " " + this.getStars() + " " + "| \n"+ ANSI_RESET);
        }
    }

    public void ten_show(){
        if(this.getStarLevel().equals("3")) {
            if(this.getName().equals("星野(泳装)")) {
                System.out.print(ANSI_LIGHT_PURPLE +"| " + this.getName() + " " + this.getStars() + " " + "| "+ ANSI_RESET);
            }
            else{System.out.print(ANSI_PURPLE +"| " + this.getName() + " " + this.getStars() + " " + "| "+ ANSI_RESET);}
        }else if (this.getStarLevel().equals("2")){
            System.out.print(BRIGHT_YELLOW+"| " + this.getName() + " " + this.getStars() + " " + "| "+ ANSI_RESET);
        }
        else{
            System.out.print(BRIGHT_BLUE+"| " + this.getName() + " " + this.getStars() + " " + "| "+ ANSI_RESET);
        }
    }
}