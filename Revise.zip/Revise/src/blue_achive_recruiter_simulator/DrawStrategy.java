package blue_achive_recruiter_simulator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public interface DrawStrategy {
    StudentCard draw();
}

abstract class Caculator{
    public Caculator(){}
    public abstract int calculate();
    public abstract int special_calculate();

}
class ProbabilityCalculator extends Caculator{
    private Random random;

    public ProbabilityCalculator(){
        this.random = new Random();
    }

    public int calculate(){
        double rand = random.nextDouble()*100;

        if(rand<3){
            double subRand = random.nextDouble()*100;
            if(subRand<(0.7/3*100)){
                return 0;
            }else{
                return 1;
            }
        } else if (rand<21.75) {
            return 2;
        }else{
            return 3;
        }
    }

    public int special_calculate(){
        double rand = random.nextDouble()*100;

        if(rand<3){
            double subRand = random.nextDouble()*100;
            if(subRand<(0.7/3*100)){
                return 0;
            }else{
                return 1;
            }
        } else{
            return 2;
        }
    }
}

class FES_ProbabilityCalculator extends Caculator{
    private Random random;

    public FES_ProbabilityCalculator(){
        this.random = new Random();
    }

    public int calculate(){
        double rand = (0.01 + random.nextDouble() * 0.99)*100;

        if(rand<=6){
            if(rand<1.4){
                return 0;
            }else{
                return 1;
            }
        } else if (rand >6 && rand<=21.75) {
            return 2;
        }else{
            return 3;
        }
    }

    public int special_calculate(){
        double rand = (0.01 + random.nextDouble() * 0.99)*100;

        if(rand<=6){
            if(rand<1.4){
                return 0;
            }else{
                return 1;
            }
        } else{
            return 2;
        }
    }
}

class SingleStrategy implements DrawStrategy {
    private Caculator caculator;
    private List<StudentCard> cardPool;

    public SingleStrategy(Caculator caculator, List<StudentCard> cardPool) {
        this.caculator = caculator;
        this.cardPool = cardPool;
    }

    @Override
    public StudentCard draw() {
        int result = caculator.calculate();
        StudentCard card = null;
        switch (result) {
            case 0:
                card = getUp3StarCard();
                break;
            case 1:
                card = getNonUp3StarCard();
                break;
            case 2:
                card = get2StarCard();
                break;
            case 3:
                card = get1StarCard();
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + result);
        }

        if (card == null) {
            throw new IllegalStateException("No card found for the given criteria.");
        }

        return card;
    }

    private StudentCard getUp3StarCard() {
        // 从卡池中选择一张UP的3星卡
        List<StudentCard> cards = cardPool.stream()
                .filter(card -> card.getStarLevel().equals("3") && card.getUp())
                .collect(Collectors.toList());
        if (cards.isEmpty()) {
            return null;
        }
        return cards.get(new Random().nextInt(cards.size()));
    }

    private StudentCard getNonUp3StarCard() {
        // 从卡池中选择一张非UP的3星卡
        List<StudentCard> cards = cardPool.stream()
                .filter(card -> card.getStarLevel().equals("3") && !card.getUp())
                .collect(Collectors.toList());
        if (cards.isEmpty()) {
            return null;
        }
        return cards.get(new Random().nextInt(cards.size()));
    }

    private StudentCard get2StarCard() {
        // 从卡池中选择一张2星卡
        List<StudentCard> cards = cardPool.stream()
                .filter(card -> card.getStarLevel().equals("2"))
                .collect(Collectors.toList());
        if (cards.isEmpty()) {
            return null;
        }
        return cards.get(new Random().nextInt(cards.size()));
    }

    private StudentCard get1StarCard() {
        // 从卡池中选择一张1星卡
        List<StudentCard> cards = cardPool.stream()
                .filter(card -> card.getStarLevel().equals("1"))
                .collect(Collectors.toList());
        if (cards.isEmpty()) {
            return null;
        }
        return cards.get(new Random().nextInt(cards.size()));
    }
}

class TenDrawStrategy implements DrawStrategy {
    private Caculator caculator;
    private List<StudentCard> cardPool;
    private List<StudentCard> ten_draws;

    public TenDrawStrategy(Caculator caculator, List<StudentCard> cardPool) {
        this.caculator = caculator;
        this.cardPool = cardPool;
    }

    public List<StudentCard> ten_draw_result() {
        int index;
        List<StudentCard> ten_draw = new ArrayList<StudentCard>();
        for(index = 0;index < 10;index++) {
            if(index<9) {
                int result = caculator.calculate();
                StudentCard card = null;
                switch (result) {
                    case 0:
                        card = getUp3StarCard();
                        ten_draw.add(card);
                        break;
                    case 1:
                        card = getNonUp3StarCard();
                        ten_draw.add(card);
                        break;
                    case 2:
                        card = get2StarCard();
                        ten_draw.add(card);
                        break;
                    case 3:
                        card = get1StarCard();
                        ten_draw.add(card);
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + result);
                }

                if (card == null) {
                    throw new IllegalStateException("No card found for the given criteria.");
                }
            }else{
                int result = caculator.special_calculate();
                StudentCard card = null;
                switch (result) {
                    case 0:
                        card = getUp3StarCard();
                        ten_draw.add(card);
                        break;
                    case 1:
                        card = getNonUp3StarCard();
                        ten_draw.add(card);
                        break;
                    case 2:
                        card = get2StarCard();
                        ten_draw.add(card);
                        break;
                    case 3:
                        card = get1StarCard();
                        ten_draw.add(card);
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + result);
                }

                if (card == null) {
                    throw new IllegalStateException("No card found for the given criteria.");
                }
            }
        }

        return ten_draw;
    }

    private StudentCard getUp3StarCard() {
        // 从卡池中选择一张UP的3星卡
        List<StudentCard> cards = cardPool.stream()
                .filter(card -> card.getStarLevel().equals("3") && card.getUp())
                .collect(Collectors.toList());
        if (cards.isEmpty()) {
            return null;
        }
        return cards.get(new Random().nextInt(cards.size()));
    }

    private StudentCard getNonUp3StarCard() {
        // 从卡池中选择一张非UP的3星卡
        List<StudentCard> cards = cardPool.stream()
                .filter(card -> card.getStarLevel().equals("3") && !card.getUp())
                .collect(Collectors.toList());
        if (cards.isEmpty()) {
            return null;
        }
        return cards.get(new Random().nextInt(cards.size()));
    }

    private StudentCard get2StarCard() {
        // 从卡池中选择一张2星卡
        List<StudentCard> cards = cardPool.stream()
                .filter(card -> card.getStarLevel().equals("2"))
                .collect(Collectors.toList());
        if (cards.isEmpty()) {
            return null;
        }
        return cards.get(new Random().nextInt(cards.size()));
    }

    private StudentCard get1StarCard() {
        // 从卡池中选择一张1星卡
        List<StudentCard> cards = cardPool.stream()
                .filter(card -> card.getStarLevel().equals("1"))
                .collect(Collectors.toList());
        if (cards.isEmpty()) {
            return null;
        }
        return cards.get(new Random().nextInt(cards.size()));
    }

    @Override
    public StudentCard draw() {
        return null;
    }
}
