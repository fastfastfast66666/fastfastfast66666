package decorator;

public interface Book{
    public String getTitle();
    double getPrice();
}
class MangaBook implements Book{
    String title = "mangabook";
    double price = 5.0;

    public String getTitle(){
        return title;
    }

    public double getPrice(){
        return price;
    }
}

abstract class BookDecorator implements Book {
    protected Book book;

    public BookDecorator(Book book) {
        this.book = book;
    }

    public String getTitle(){
        return book.getTitle();
    }

    public double getPrice(){
        return book.getPrice();
    }
}

class DiscountDecorator extends BookDecorator{
public DiscountDecorator(Book book){
    super(book);
}
public String getTitle(){
    return book.getTitle()+"打折了";
}

public double getPrice(){
    return book.getPrice()-2.0;
}
}

class GiftDecorator extends BookDecorator{
    public GiftDecorator(Book book){
        super(book);
    }
    public String getTitle(){
        return book.getTitle()+"礼品包装了";
    }

    public double getPrice(){
        return book.getPrice()+2.0;
    }

}


class Demo{
    public static void main(String[] args) {
        MangaBook mangaBook = new MangaBook();
        System.out.printf("书名："+mangaBook.getTitle()+"价格："+mangaBook.getPrice()+"\n");
        System.out.printf("-------------------打折装饰后----------------------"+"\n");
        DiscountDecorator discountDecorator = new DiscountDecorator(mangaBook);
        GiftDecorator giftDecorator = new GiftDecorator(mangaBook);
        System.out.printf("书名："+discountDecorator.getTitle());
        System.out.printf("价格："+discountDecorator.getPrice()+"\n");

        System.out.printf("-------------------包装装饰后----------------------"+"\n");
        System.out.printf("书名："+giftDecorator.getTitle());
        System.out.printf("价格："+giftDecorator.getPrice()+"\n");
    }
}


