package decorator;

public interface Beverage {
    String getDiscription();
    double cost();
}

class coffee implements Beverage{
    @Override
    public String getDiscription() {
        return null;
    }

    @Override
    public double cost() {
        return 0;
    }
}

