package abstractFactory;

public interface Operation {
    public int caculate(int a,int b);
}

class Plus implements Operation{

    @Override
    public int caculate(int a,int b) {
        return a + b;
    }
}

class Minus implements Operation{

    @Override
    public int caculate(int a,int b) {
        return a - b;
    }
}
class Multiply implements Operation{

    @Override
    public int caculate(int a,int b) {
        return a * b;
    }
}
class Divide implements Operation{

    @Override
    public int caculate(int a,int b) {
        return a / b;
    }
}

