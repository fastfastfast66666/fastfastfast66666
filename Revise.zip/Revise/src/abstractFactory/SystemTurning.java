package abstractFactory;

public interface SystemTurning {
    public int Turn_2_To_10(String binary);
    public String Turn_10_To_2(int decimal);
}

class Binary_To_Decimal implements SystemTurning{
    @Override
    public int Turn_2_To_10(String binary) {
        return Integer.parseInt(binary,2);
    }

    @Override
    public String Turn_10_To_2(int decimal) {
        return null;
    }
}

class Decimal_To_Binary implements SystemTurning{
    @Override
    public int Turn_2_To_10(String binary) {
        return 0;
    }

    @Override
    public String Turn_10_To_2(int decimal) {
        return Integer.toBinaryString(decimal);
    }
}
