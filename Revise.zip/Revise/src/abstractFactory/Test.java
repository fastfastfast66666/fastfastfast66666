package abstractFactory;

public class Test {
    public static void main(String[] args) {
        FactoryProducer producer = new FactoryProducer();

        AbstractFactory operationFactory = producer.getFactory("operation");
        AbstractFactory systemFactory = producer.getFactory("other");

        int result1 = operationFactory.getOperation("+").caculate(3,4);
        System.out.printf("3+4 十进制结果为"+result1+"\n");
        String result2 = systemFactory.getSystem("D2B").Turn_10_To_2(result1);
        System.out.printf("3+4 二进制结果为"+result2);
    }
}
