package abstractFactory;

public interface AbstractFactory {
    public Operation getOperation(String operationSign);
    public SystemTurning getSystem(String system);
}

class AbstractOperationFactory implements AbstractFactory{
    Operation operation;
    @Override
    public Operation getOperation(String operationSign) {
        if (operationSign.equals("+")){
            operation = new Plus();
        } else if (operationSign.equals("-")) {
            operation = new Minus();
        }else if(operationSign.equals("*")){
            operation = new Multiply();
        }else {
            operation = new Divide();
        }
        return operation;
    }

    @Override
    public SystemTurning getSystem(String system) {
        return null;
    }
}

class AbstractSystemFactory implements AbstractFactory{
    SystemTurning systemTurning;
    @Override
    public Operation getOperation(String operation) {
        return null;
    }

    @Override
    public SystemTurning getSystem(String system) {
        if(system.equals("B2D")){
            systemTurning = new Binary_To_Decimal();
        }else {
            systemTurning = new Decimal_To_Binary();
        }
        return systemTurning;
    }
}

class FactoryProducer{
    public AbstractFactory getFactory(String choice){
        if(choice.equals("operation")){
            return new AbstractOperationFactory();
        }else {
            return new AbstractSystemFactory();
        }
    }
}